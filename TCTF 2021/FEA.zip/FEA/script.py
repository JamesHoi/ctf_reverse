#!/usr/bin/python
from pwn import *
from hashlib import sha256
from base64 import b64decode

def getXXXX(part2, dst):
	table = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
	for a in table:
		for b in table:
			for c in table:
				for d in table:
					if sha256(a + b + c + d + part2).hexdigest() == dst:
						return a + b + c + d

# context.log_level = 'debug'
p = remote('111.186.58.164', 30212)
dst = p.recvline().strip('\n')
part2, dst = dst.split(' == ')
part2 = part2.split('+')[1][:-1]
p.recvline()
p.sendline(getXXXX(part2, dst))
p.recvuntil('challenge:\n\n')
open('chall5', 'wb').write(b64decode(p.recvline()[:-1]))

p.interactive()